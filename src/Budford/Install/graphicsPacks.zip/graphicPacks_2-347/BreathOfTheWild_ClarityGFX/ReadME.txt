There is currently 3 releases of Clarity in this pack,
The default is with No lumasharpening or HDR.
The second titled.lumasharpening is the same file as above but with lumashapening.
The third FakeHDR is the same but with Faked HDR 

You cannot Enable all 3 packs at once , so you need to rename the file by removing the ending extention .lumasharpening or FakeHDR .   
The Origional File I would back upto its name.txt.origional case you want to revert for any reason.
	
Please Note sword effect's are slightly off in Faked HDR .. Looking for a solution.
lumasharpening and FakeHDR were Brought over from SweetFX, Reshade to be used as a 1- pass shader .. They cannot be enabled or used at the same time..